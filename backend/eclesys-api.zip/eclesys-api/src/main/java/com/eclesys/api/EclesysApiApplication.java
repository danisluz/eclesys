package com.eclesys.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EclesysApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EclesysApiApplication.class, args);
	}

}
