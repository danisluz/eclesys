package com.eclesys.api.domain.user;

public enum UserRole {
  ADMIN,
  SECRETARIA,
  LIDER
}
